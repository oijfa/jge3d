/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTSeparateSpecularColor {

	public static final int GL_SINGLE_COLOR_EXT = 0x81F9,
		GL_SEPARATE_SPECULAR_COLOR_EXT = 0x81FA,
		GL_LIGHT_MODEL_COLOR_CONTROL_EXT = 0x81F8;

	private EXTSeparateSpecularColor() {}
}
