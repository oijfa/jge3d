/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ATITextureEnvCombine3 {

	/**
	 *  Accepted by the &lt;params&gt; parameter of TexEnvf, TexEnvi, TexEnvfv,
	 *  and TexEnviv when the &lt;pname&gt; parameter value is COMBINE_RGB_ARB
	 *  or COMBINE_ALPHA_ARB
	 */
	public static final int GL_MODULATE_ADD_ATI = 0x8744,
		GL_MODULATE_SIGNED_ADD_ATI = 0x8745,
		GL_MODULATE_SUBTRACT_ATI = 0x8746;

	private ATITextureEnvCombine3() {}
}
