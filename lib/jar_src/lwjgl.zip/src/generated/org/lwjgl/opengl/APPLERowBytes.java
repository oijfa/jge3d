/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLERowBytes {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of PixelStorei and the &lt;pname&gt;
	 *  parameter of GetIntegerv:
	 */
	public static final int GL_PACK_ROW_BYTES_APPLE = 0x8A15,
		GL_UNPACK_ROW_BYTES_APPLE = 0x8A16;

	private APPLERowBytes() {}
}
