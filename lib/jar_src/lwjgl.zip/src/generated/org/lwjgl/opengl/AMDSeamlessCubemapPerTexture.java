/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDSeamlessCubemapPerTexture {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameterf, TexParameteri,
	 *  TexParameterfv, TexParameteriv, GetTexParameterfv, and GetTexParameteriv:
	 */
	public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 0x884F;

	private AMDSeamlessCubemapPerTexture() {}
}
