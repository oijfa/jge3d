/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class APPLEPackedPixels {

	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels, TexImage1D,
	 *  TexImage2D, GetTexImage, TexImage3D, TexSubImage1D,
	 *  TexSubImage2D, TexSubImage3D, GetHistogram, GetMinmax,
	 *  ConvolutionFilter1D, ConvolutionFilter2D, ConvolutionFilter3D,
	 *  GetConvolutionFilter, SeparableFilter2D, SeparableFilter3D,
	 *  GetSeparableFilter, ColorTable, GetColorTable, TexImage4DSGIS,
	 *  and TexSubImage4DSGIS:
	 */
	public static final int GL_UNSIGNED_BYTE_3_3_2 = 0x8032,
		GL_UNSIGNED_BYTE_2_3_3_REV = 0x8362,
		GL_UNSIGNED_SHORT_5_6_5 = 0x8363,
		GL_UNSIGNED_SHORT_5_6_5_REV = 0x8364,
		GL_UNSIGNED_SHORT_4_4_4_4 = 0x8033,
		GL_UNSIGNED_SHORT_4_4_4_4_REV = 0x8365,
		GL_UNSIGNED_SHORT_5_5_5_1 = 0x8034,
		GL_UNSIGNED_SHORT_1_5_5_5_REV = 0x8366,
		GL_UNSIGNED_INT_8_8_8_8 = 0x8035,
		GL_UNSIGNED_INT_8_8_8_8_REV = 0x8367,
		GL_UNSIGNED_INT_10_10_10_2 = 0x8036,
		GL_UNSIGNED_INT_2_10_10_10_REV = 0x8368;

	private APPLEPackedPixels() {}
}
