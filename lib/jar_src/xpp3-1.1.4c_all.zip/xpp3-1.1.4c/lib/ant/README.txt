Contains all that is required to build package with ANT
For more details please see: http://jakarta.apache.org/ant/
