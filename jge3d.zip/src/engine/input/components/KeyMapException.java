package engine.input.components;

public class KeyMapException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;}
