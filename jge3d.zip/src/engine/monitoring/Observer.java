package engine.monitoring;

public interface Observer {
	public void update(Object o);
}
