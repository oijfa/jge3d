package editor.action_listener;

public interface ActionListener {
	public void actionPerformed(ActionEvent ae);
}
